var searchData=
[
  ['srix4k_5fblocks_191',['SRIX4K_BLOCKS',['../mikai_8h.html#a479f79bb1a42277e219afdacff921d4d',1,'mikai.h']]],
  ['srix4k_5fbytes_192',['SRIX4K_BYTES',['../mikai_8h.html#af3777586db4dfdf18851fd2155f15feb',1,'mikai.h']]],
  ['srix_5fblock_5flength_193',['SRIX_BLOCK_LENGTH',['../mikai_8h.html#a3faa51be926ca9006f9c7e4873c3f085',1,'mikai.h']]],
  ['srix_5fflag_5finit_194',['SRIX_FLAG_INIT',['../srix-flag_8h.html#a1d5d1479e5f6ae1726ee4531ca13a377',1,'srix-flag.h']]],
  ['srix_5fget_5fuid_195',['SRIX_GET_UID',['../reader_8c.html#aa687d452aad7449ad88c70c8651f9d7a',1,'reader.c']]],
  ['srix_5fread_5fblock_196',['SRIX_READ_BLOCK',['../reader_8c.html#a54c608ae47a593ec0e961f0d7f8fe2a2',1,'reader.c']]],
  ['srix_5fuid_5flength_197',['SRIX_UID_LENGTH',['../mikai_8h.html#ac0d11e0967b39bc66b985c88499257ca',1,'mikai.h']]],
  ['srix_5fwrite_5fblock_198',['SRIX_WRITE_BLOCK',['../reader_8c.html#a6691dcd83117e41b85837c2f625e0c11',1,'reader.c']]]
];
