var searchData=
[
  ['reader_66',['reader',['../structSrix.html#a77f4b5aec3ab95c9fd31dd829b66b47d',1,'Srix']]],
  ['reader_2ec_67',['reader.c',['../reader_8c.html',1,'']]],
  ['reader_2eh_68',['reader.h',['../reader_8h.html',1,'']]],
  ['readme_2emd_69',['README.md',['../README_8md.html',1,'']]]
];
