var searchData=
[
  ['generic_8',['generic',['../structSrix.html#aba8b06efbb6b5a96cba777f2689acae1',1,'Srix']]]
];
