var searchData=
[
  ['block_0',['block',['../structSrixBlock.html#affca736a65bf412a52c17c3668913470',1,'SrixBlock']]],
  ['blockflags_1',['blockFlags',['../structSrix.html#a4b5bec452c2a9d594029d28d78358ff8',1,'Srix']]]
];
