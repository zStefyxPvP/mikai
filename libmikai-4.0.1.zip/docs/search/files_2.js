var searchData=
[
  ['srix_2dflag_2ec_112',['srix-flag.c',['../srix-flag_8c.html',1,'']]],
  ['srix_2dflag_2eh_113',['srix-flag.h',['../srix-flag_8h.html',1,'']]],
  ['srix_2ec_114',['srix.c',['../srix_8c.html',1,'']]],
  ['srix_2eh_115',['srix.h',['../srix_8h.html',1,'']]]
];
